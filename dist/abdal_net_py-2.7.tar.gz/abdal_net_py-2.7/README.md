# Abdal Net Py


## Made For



Powerful security network package for hackers and all security experts



**Requires Lib**
> hurry.filesize - psutil


**Requires python**
> Python >= 3.9



## Features


- calculate internet speed with unit
- calculate byte to other unit (show in xbit vs xbyte )
- Convert byte to other unit by select unit
- multi password generator 
- log writer + logging ram and cpu usage
- iranian mobile phone generate
- 

**How To install**

```py
pip install abdal-net-py
```

**How To use**

```py
import abdal_net_py
```


## ❤️ Donation

> USDT:      TXLasexoQTjKMoWarikkfYRYWWXtbaVadB

> BTC :   bc1q9w9ymgz2wluax60rsuza4q0at7gpy82g8el6zj

> ETH :   0x402b9f67091Af07224286F16d7377bc50268Db94

> For Iranian People -> MellatBank : 6104-3378-5301-4247

## 🤵 Programmer
Ebrahim Shafiei (EbraSha)

E-Mail = Prof.Shafiei@Gmail.com

Telegram: https://t.me/ProfShafiei


## License
Abdal Net Py is open-source software licensed under the [MIT license.](https://choosealicense.com/licenses/mit/)


## ☠️ Reporting Issues

If you are facing a configuration issue or something is not working as you expected to be, please use the **Prof.Shafiei@Gmail.com** . Issues on GitLab are also welcomed.

## ⚠️ Legal disclaimer ⚠️

Usage of Abdal Net Py for Spying targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.




