# Abdal Net Py


## Made For



Powerful security network package for hackers and all security experts



**Requires Lib**
> hurry.filesize - psutil


**Requires python**
> Python >= 3.9



## Features


- calculate internet speed with unit
- calculate byte to other unit (show in xbit vs xbyte )
- Convert byte to other unit by select unit
- multi password generator 
- log writer + logging ram and cpu usage
- iranian mobile phone generate
- 

**How To install**

```py
pip install abdal-net-py
```

**How To use**

```py
import abdal_net_py
```


## ❤️ Donation
> USDT:      TXLasexoQTjKMoWarikkfYRYWWXtbaVadB

> bitcoin:   19LroTSwWcEBY2XjvgP6X4d6ECZ17U2XsK

> For Iranian People -> MellatBank : 6104-3378-5301-4247


## Reporting Issues 

If you are facing a configuration issue or something is not working as you expected to be, please use the **Abdal.Group@Gmail.Com** or **Prof.Shafiei@Gmail.com** . Issues on GitLab are also welcomed.




### About Programmer
Ebrahim Shafiei (EbraSha) (Ready to cooperate with international projects)
- Email : Prof.Shafiei@Gmail.com


## License
Abdal Net Py is open-source software licensed under the [MIT license.](https://choosealicense.com/licenses/mit/)


## ⚠️ Legal disclaimer ⚠️

Usage of Abdal Net Py for Spying targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.




