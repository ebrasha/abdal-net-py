def ebrasha():
    banner = """
         ______________
        ||            ||
        ||            ||
        ||            ||
        ||            ||
        ||____________||
        |______________|
         \\\\############\\\\
          \\\\############\\\\
           \\      ____    \\   
            \\_____\\___\\____\\
    
        Programmer : Ebrahim Shafiei (EbraSha)
        Creator Email : Prof.Shafiei@Gmail.com
        Bug Report : Prof.Shafiei@Gmail.com
        
    """
    print(banner)
